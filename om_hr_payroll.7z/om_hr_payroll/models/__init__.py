# -*- coding:utf-8 -*-

from . import hr_leave_type
from . import hr_contract_type
from . import hr_contract
from . import hr_employee
from . import res_config_settings
from . import hr_salary_rule
from . import hr_payslip
from . import resource_mixin
